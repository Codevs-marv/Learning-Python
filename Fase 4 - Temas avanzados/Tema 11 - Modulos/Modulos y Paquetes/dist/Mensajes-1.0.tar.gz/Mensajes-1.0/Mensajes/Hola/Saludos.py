def saludar():
    print('Hola te saludo desde saludos.saludar()')



class saludo:
    def __init__(self):
        print('Hola, te saludo desde saludo')

# Comprobación
# Solo se ejecutará en este script
if __name__ == '__main__':
    saludar()

