def despedir():
    print('Adiós, me despido desde Despedidas.despedir()')


class Despedida:
    def __init__(self) -> None:
        print('Adiós, me despido desde Despedidas.Despedida')