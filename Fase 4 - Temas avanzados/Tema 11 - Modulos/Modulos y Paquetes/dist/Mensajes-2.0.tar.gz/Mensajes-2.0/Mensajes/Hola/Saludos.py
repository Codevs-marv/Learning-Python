def saludar():
    print('Hola te saludo desde saludos.saludar()')


def Prueba():
    print('Esto es una prueba de la nueva version')

class saludo:
    def __init__(self):
        print('Hola, te saludo desde saludo')

# Comprobación
# Solo se ejecutará en este script
if __name__ == '__main__':
    saludar()

